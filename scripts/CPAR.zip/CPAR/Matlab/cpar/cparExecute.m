function cparExecute(dev, func)
% cparExecute Execute an ECP DeviceFunction
%   cparExecute(dev, func)
%
dev.Execute(func);