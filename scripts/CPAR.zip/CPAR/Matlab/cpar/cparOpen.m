function cparOpen(dev)
% cparOpen Open a CPAR device for communication
%   cparOpen(CPAR)
%
% See also, cparCreate, cparClose
dev.Open();