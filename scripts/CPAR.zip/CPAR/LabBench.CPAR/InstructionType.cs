﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabBench.CPAR
{
    public enum InstructionType
    {
        NOP = 0x00,
        INC = 0x01,
        DEC = 0x02,
        STEP = 0x03
    }
}
